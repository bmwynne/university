//
//  ViewController.swift
//  FlashCards
//
//  Created by Brandon Wynne on 9/1/16.
//  Copyright © 2016 Brandon Wynne. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var answer_label  : UILabel!
    @IBOutlet var question_label: UILabel!
    
    @IBAction func show_question(sender: AnyObject) {
        self.question_label.text = "How old are you?";
        self.answer_label.text   = "(Try guessing...!)";
        
    }
    
    @IBAction func show_answer(sender: AnyObject) {
        self.answer_label.text = "I'm 22 years old."
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    


}

