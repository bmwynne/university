//
//  SecondViewController.swift
//  FlashCards
//
//  Created by Wynne, Brandon Michael on 9/12/16.
//  Copyright © 2016 Brandon Wynne. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}