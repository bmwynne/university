Brandon Wynne, bmwynne
Partner: John Binzer, jfbinzer

Nothing changed. Same blank single view application launched from home screen.
